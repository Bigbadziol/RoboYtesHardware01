// YtesAudio.h
#ifndef _YTESAUDIO_h
#define _YTESAUDIO_h

#include "setup.h"
#include "DFRobotDFPlayerMini.h"  // DFRobotDFPlayerMini by DFRobot Version 1.0.5

enum KANAL{LEWY,PRAWY,OBA};
class YtesAudio {
private:
	const int defGlosnoscLewy = 25; //0..30
	const int defGlosnoscPrawy = 25;//0..30
	const int defKatLewy = 1; //katalog dla glosnika lewego , dla cyfry 1, fizycznie musi miec postac "001" 
	const int defKatPrawy = 2;//katalog dla glosnika prawego, dla cyfry 2, fizycznie musi miec postac "002"
	const String nagraniaLewy[3] = {"linking park-numb","czadomen-abc","abc-cdf"};
	const String nagraniaPrawy[2] = { "dzwiek 1","dzwiek 2" };

	int glosnoscLewy = defGlosnoscLewy;
	int glosnoscPrawy = defGlosnoscPrawy;
	int katLewy = defKatLewy;
	int katPrawy = defKatPrawy;


	DFRobotDFPlayerMini playerLewy;
	DFRobotDFPlayerMini playerPrawy;
	String playerStatusToStr(uint8_t type, int value);
public:
	YtesAudio();
	~YtesAudio();	
	void graj(KANAL kanal, int nrNagrania);
	void glosnosc(KANAL kanal, int wartosc);
	void obslozPolecenieDane(JsonObject* dane);
	String odpowiedz();
};

YtesAudio::YtesAudio(){
	serialLewy.begin(9600, SERIAL_8N1, SERIAL2_LEWY_RX, SERIAL2_LEWY_TX);
	serialPrawy.begin(9600, SERIAL_8N1, SERIAL1_PRAWY_RX, SERIAL1_PRAWY_TX);

	playerLewy.setTimeOut(500); //500
	playerLewy.volume(glosnoscLewy);  //0..30
	playerLewy.EQ(DFPLAYER_EQ_NORMAL); //DFPLAYER_EQ_NORMAL , DFPLAYER_EQ_POP , DFPLAYER_EQ_ROCK , DFPLAYER_EQ_JAZZ , DFPLAYER_EQ_CLASSIC , DFPLAYER_EQ_BASS
	playerLewy.outputDevice(DFPLAYER_DEVICE_SD); //DFPLAYER_DEVICE_U_DISK , DFPLAYER_DEVICE_SD , DFPLAYER_DEVICE_AUX , DFPLAYER_DEVICE_SLEEP , DFPLAYER_DEVICE_FLASH

	playerPrawy.setTimeOut(500); //500
	playerPrawy.volume(glosnoscPrawy);
	playerPrawy.EQ(DFPLAYER_EQ_NORMAL);
	playerPrawy.outputDevice(DFPLAYER_DEVICE_SD);

}

YtesAudio::~YtesAudio() {
	playerLewy.stop();
	playerPrawy.stop();
	serialLewy.end();
	serialPrawy.end();
};
/*
	Informacja zwrotna od modu�u mp3 odpowiedzialnego za lewy lub prawy g�o�nik
*/
String YtesAudio::playerStatusToStr(uint8_t type, int value) {
	String ret = "";
	switch (type) {
	case TimeOut:
		ret = "Czas uplynal";
		break;
	case WrongStack:
		ret = "Zly stos??";
		break;
	case DFPlayerCardInserted:
		ret = "Wsadzono karte";
		break;
	case DFPlayerCardRemoved:
		ret = "Usunieto karte.";		
		break;
	case DFPlayerCardOnline:
		ret = "Karta gotowa do pracy.";
		break;
	case DFPlayerUSBInserted:
		ret = "Wsadzono USB";		
		break;
	case DFPlayerUSBRemoved:
		ret = "Usunieto USB";		
		break;
	case DFPlayerPlayFinished:
		ret = "Ukonczono nagranie :";
		ret.concat(value);
		break;
	case DFPlayerError:
		ret = "Blad : ";		
		switch (value) {
		case Busy:
			ret += "nie odnaleziono karty.";			
			break;
		case Sleeping:
			ret += " uklad uspiony";
			break;
		case SerialWrongStack:
			ret += "pobrano zly stos?";			
			break;
		case CheckSumNotMatch:
			ret += "zla suma kontrolna";			
			break;
		case FileIndexOut:
			ret += "index nagrania poza zakresem";			
			break;
		case FileMismatch:
			ret += "nie moge odnalezc pliku";			
			break;
		case Advertise:
			ret += "w trybie advertise";			
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	return ret;
}
/*
* Graj nagranie dla wskazanego kanalu(glosnika). Podanie 0 spowoduje zatrzymanie nagrania dla 
* danego kana�u.
*/
void YtesAudio::graj(KANAL kanal, int nrNagrania) {
	switch (kanal) {
	case LEWY:
		if (nrNagrania <= 0) playerLewy.stop();
		else playerLewy.playFolder(katLewy, nrNagrania);
		break;
	case PRAWY:
		if (nrNagrania <= 0) playerPrawy.stop();
		playerPrawy.playFolder(katPrawy, nrNagrania);
		break;
	case OBA:
		if (nrNagrania <= 0) playerLewy.stop();
		else playerLewy.playFolder(katLewy, nrNagrania);
		if (nrNagrania <= 0) playerPrawy.stop();
		playerPrawy.playFolder(katPrawy, nrNagrania);
		break;
	default:
		break;
	};
};
/*
* Ustaw g�o�no�� dla lewego lub prawgo g�o�nika
*/
void YtesAudio::glosnosc(KANAL kanal, int wartosc) {
	int nowaWartosc = wartosc;
	if (nowaWartosc < 0) nowaWartosc = 0;
	if (nowaWartosc > 30) nowaWartosc = 30;

	switch (kanal) {
	case LEWY:
		playerLewy.volume(wartosc);
		break;
	case PRAWY:
		playerPrawy.volume(wartosc);
		break;
	case OBA:
		playerLewy.volume(wartosc);
		playerPrawy.volume(wartosc);
		break;
	default:
		break;
	};
};
/*
* Obsluga samego bloku dane, zatem przykladowy spodziewany obiekt ma mie� posta� :
* {
		"LG" : 25,		<- Lewy glosnosc (domyslnie muzyka)
		"PG" : 15,		<- Prawy glosnosc (domyslnie efekty dzwiekowe)
		"LN" : 3		<- Lewy nagranie (numer nagrania z wczesniej wskazanego katalogu)
* }
*/
void YtesAudio::obslozPolecenieDane(JsonObject* dane) {
	//const char* vLG = (*dane)["KLUCZ"].as<const char*>(); //lyka
	//int noweDane = (*dane)["LG"].as<int>();//lyka
	//if (noweDane) {}
	
	//lewy glosnosc

	JsonVariant vLG = (*dane)["LG"];
	if (!vLG.isNull()) {
		glosnosc(LEWY, vLG.as<int>());
		AUDIO_INFO_V("Glosnik lewy glosnosc ustawiona :", vLG.as<int>());
	};

	//prawy glosnosc
	JsonVariant vPG = (*dane)["PG"];
	if (!vPG.isNull()) {
		glosnosc(PRAWY, vPG.as<int>());
		AUDIO_INFO_V("Glosnik lewy glosnosc ustawiona :", vPG.as<int>());
	};

	//lewy nagranie
	JsonVariant vLN = (*dane)["LN"];
	if (!vLN.isNull()) {
		graj(LEWY, vLN.as<int>());
		AUDIO_INFO_VV("Glosnik lewy nagranie (kat/nagranie) :", katLewy, vLN.as<int>());
	}
	//prawy nagranie
	JsonVariant vPN = (*dane)["PN"];
	if (!vPN.isNull()) {
		graj(PRAWY, vPN.as<int>());
		AUDIO_INFO_VV("Glosnik prawy nagranie (kat/nagranie) :", katPrawy, vPN.as<int>());
	}
	//restart playerow
	JsonVariant vRestart = (*dane)["RESTART"];
	if (!vRestart.isNull()) {
		int v = vRestart.as<int>();
		if (v == 1) {
			playerLewy.reset();
			playerPrawy.reset();
		}
	}
}
/*
* 
*/
String YtesAudio::odpowiedz() {
	//DynamicJsonDocument resDoc(2048);
	//JsonObject obj = resDoc.as<JsonObject>();
	//obj["cmd"] = "audioResp";
	//JsonObject objData = obj.createNestedObject("data");	
	//JsonArray arrL = objData.createNestedArray("L");
	//JsonArray arrP = objData.createNestedArray("P");
	 
/*
	for (int i = 0; i < nagraniaLewy->length(); i++) {
		arrL.add(nagraniaLewy[i]);
	};
	for (int i = 0; i < nagraniaPrawy->length(); i++) {
		arrP.add(nagraniaPrawy[i]);
	};
*/
	String tmp="";
	//size_t resSize = serializeJson(resDoc, tmp);
	return tmp;
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------
/*
const char* dupa = root["LG"];
if (dupa) {
	Serial.println(dupa);
	return;
}
*/

/*
void test() {
	StaticJsonDocument<256> doc;
	JsonObject jo= doc.to<JsonObject>();

	JsonVariant vLG = jo["LG"];
	if (!vLG.isNull()) {
		int wartosc = vLG.as<int>();
	}
}
*/

//--------------------------------------------------------------------
/*
class YtesAudio {
public:
	void obslozPolecenieDane(JsonObject* dane) {
		// uzyskanie warto�ci pola KLUCZ
		const char* vLG = (*dane)["KLUCZ"].as<const char*>();

		// sprawdzenie, czy warto�� jest null lub nie istnieje
		if (vLG == nullptr) {
			Serial.println(F("Error: KLUCZ is missing"));
			return;
		}

		Serial.println(vLG);
	}
};

void setup() {
	// utworzenie przyk�adowego obiektu JSON
	DynamicJsonDocument doc(1024);
	deserializeJson(doc, "{\"KLUCZ\": \"wartosc\"}");

	// uzyskanie wska�nika na obiekt JSON
	JsonObject* dane = &doc.as<JsonObject>();

	YtesAudio audio;
	audio.obslozPolecenieDane(dane);
}

void loop() {
	
}
*/
#endif